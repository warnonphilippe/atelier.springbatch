create view member_comments(book_id, member_id, date, text) as
SELECT book_comments.book_id,
       book_comments.member_id,
       book_comments.date,
       book_comments.text
FROM book_comments;

alter table member_comments
    owner to postgres;

