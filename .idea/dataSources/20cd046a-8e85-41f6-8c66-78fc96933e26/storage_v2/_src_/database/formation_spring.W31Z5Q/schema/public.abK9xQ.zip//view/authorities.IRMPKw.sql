create view authorities(username, authority) as
SELECT m.username,
       ma.authority
FROM member_authorities ma
         JOIN member m ON ma.member_id = m.id;

alter table authorities
    owner to postgres;

