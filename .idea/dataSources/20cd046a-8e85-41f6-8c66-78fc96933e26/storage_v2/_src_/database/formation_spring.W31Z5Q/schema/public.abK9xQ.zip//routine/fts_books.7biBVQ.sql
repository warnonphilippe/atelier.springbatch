create function fts_books(title character varying, author character varying)
    returns TABLE(id integer, title character varying, author character varying)
    language sql
as
$$
    select 
        b.id, 
        b.title, 
        a.fullname as author 
    from Book b join Author a on b.author_id = a.id
    where 
    	case when $1 is null then true else b.title % $1 end
    	and
    	case when $2 is null then true else a.lastname % $2 end
    order by b.id
$$;

alter function fts_books(varchar, varchar) owner to postgres;

